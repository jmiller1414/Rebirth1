document.querySelectorAll('.faq h3').forEach(faq => {
    faq.addEventListener('click', () => {
        const content = faq.nextElementSibling;
        content.style.display = content.style.display === 'block' ? 'none' : 'block';
    });
});